"""
gui.py — Interface gráfica PySide6 para o gerador de estruturas.

Recursos:
  - Sidebar com templates prontos (Flask, FastAPI, Django, React, Node, Python CLI)
  - Editor da árvore ASCII (livre, pode ser editado)
  - Preview hierárquico em tempo real
  - Seletor de pasta de destino
  - Carregar template a partir de arquivo .txt
  - Modo "dry-run" (apenas pré-visualizar)
  - Tema escuro moderno
"""

from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QIcon, QAction
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSplitter,
    QStatusBar,
    QVBoxLayout,
    QWidget,
)

from generator import create_structure, open_in_explorer, parse_tree, tree_preview
from templates_data import TEMPLATES


DARK_QSS = """
QMainWindow, QWidget {
    background-color: #1b1d23;
    color: #e6e6e6;
}
QLabel#title {
    font-size: 20px;
    font-weight: 600;
    color: #ffd166;
}
QLabel#subtitle {
    color: #8a8f99;
    font-size: 12px;
}
QListWidget {
    background-color: #232730;
    border: 1px solid #2e333d;
    border-radius: 8px;
    padding: 6px;
}
QListWidget::item {
    padding: 10px 12px;
    border-radius: 6px;
    margin: 2px 0;
}
QListWidget::item:selected {
    background-color: #ffd166;
    color: #1b1d23;
    font-weight: 600;
}
QListWidget::item:hover {
    background-color: #2e333d;
}
QPlainTextEdit, QLineEdit {
    background-color: #232730;
    border: 1px solid #2e333d;
    border-radius: 8px;
    padding: 8px;
    color: #e6e6e6;
    font-family: "JetBrains Mono", "Consolas", monospace;
    font-size: 13px;
    selection-background-color: #ffd166;
    selection-color: #1b1d23;
}
QPushButton {
    background-color: #2e333d;
    color: #e6e6e6;
    border: 1px solid #3a4150;
    padding: 8px 14px;
    border-radius: 8px;
    font-weight: 500;
}
QPushButton:hover { background-color: #3a4150; }
QPushButton#primary {
    background-color: #ffd166;
    color: #1b1d23;
    border: none;
}
QPushButton#primary:hover { background-color: #ffbf3b; }
QPushButton#primary:disabled { background-color: #5a5a5a; color: #2a2a2a; }
QCheckBox { color: #c9ced9; }
QStatusBar { background-color: #14161a; color: #8a8f99; }
QSplitter::handle { background-color: #2e333d; }
"""


class GeneratorWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Project Tree Generator")
        self.resize(1180, 720)
        self.setStyleSheet(DARK_QSS)

        self._build_ui()
        self._wire_events()
        # Seleciona o primeiro template por padrão
        self.template_list.setCurrentRow(0)

    # ----------------- UI -----------------

    def _build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        root_layout = QHBoxLayout(root)
        root_layout.setContentsMargins(16, 16, 16, 16)
        root_layout.setSpacing(14)

        # Sidebar
        sidebar = QWidget()
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("Templates prontos")
        title.setObjectName("title")
        subtitle = QLabel("Escolha um modelo e personalize a árvore.")
        subtitle.setObjectName("subtitle")
        sidebar_layout.addWidget(title)
        sidebar_layout.addWidget(subtitle)

        self.template_list = QListWidget()
        for tpl in TEMPLATES.values():
            item = QListWidgetItem(tpl.name)
            item.setData(Qt.UserRole, tpl.key)
            item.setToolTip(tpl.description)
            self.template_list.addItem(item)
        sidebar_layout.addWidget(self.template_list, 1)

        self.btn_load_file = QPushButton("Carregar arquivo .txt…")
        sidebar_layout.addWidget(self.btn_load_file)

        sidebar.setFixedWidth(280)
        root_layout.addWidget(sidebar)

        # Editor + Preview (splitter horizontal)
        center = QSplitter(Qt.Horizontal)

        # Editor
        editor_box = QWidget()
        editor_layout = QVBoxLayout(editor_box)
        editor_layout.setContentsMargins(0, 0, 0, 0)
        editor_label = QLabel("Árvore ASCII (editável)")
        editor_label.setObjectName("title")
        editor_layout.addWidget(editor_label)

        self.editor = QPlainTextEdit()
        self.editor.setPlaceholderText("Cole ou edite a estrutura em árvore aqui…")
        editor_layout.addWidget(self.editor, 1)

        # Preview
        preview_box = QWidget()
        preview_layout = QVBoxLayout(preview_box)
        preview_layout.setContentsMargins(0, 0, 0, 0)
        preview_label = QLabel("Pré-visualização")
        preview_label.setObjectName("title")
        preview_layout.addWidget(preview_label)

        self.preview = QPlainTextEdit()
        self.preview.setReadOnly(True)
        preview_layout.addWidget(self.preview, 1)

        center.addWidget(editor_box)
        center.addWidget(preview_box)
        center.setSizes([520, 380])

        # Coluna direita
        right_col = QVBoxLayout()
        right_col.setSpacing(10)
        right_col.addWidget(center, 1)

        # Linha de destino
        dest_row = QHBoxLayout()
        self.dest_input = QLineEdit()
        self.dest_input.setPlaceholderText("Pasta de destino…")
        self.btn_browse = QPushButton("Procurar…")
        dest_row.addWidget(QLabel("Destino:"))
        dest_row.addWidget(self.dest_input, 1)
        dest_row.addWidget(self.btn_browse)
        right_col.addLayout(dest_row)

        # Opções + ações
        actions_row = QHBoxLayout()
        self.chk_open = QCheckBox("Abrir pasta ao final")
        self.chk_open.setChecked(True)
        self.chk_use_files = QCheckBox("Usar conteúdo inicial do template")
        self.chk_use_files.setChecked(True)
        self.chk_dry = QCheckBox("Dry-run (não criar arquivos)")
        actions_row.addWidget(self.chk_open)
        actions_row.addWidget(self.chk_use_files)
        actions_row.addWidget(self.chk_dry)
        actions_row.addStretch(1)
        self.btn_generate = QPushButton("Gerar estrutura")
        self.btn_generate.setObjectName("primary")
        actions_row.addWidget(self.btn_generate)
        right_col.addLayout(actions_row)

        wrapper = QWidget()
        wrapper.setLayout(right_col)
        root_layout.addWidget(wrapper, 1)

        # Status bar
        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage("Pronto.")

    # ----------------- Eventos -----------------

    def _wire_events(self) -> None:
        self.template_list.currentItemChanged.connect(self._on_template_changed)
        self.editor.textChanged.connect(self._refresh_preview)
        self.btn_browse.clicked.connect(self._choose_dest)
        self.btn_load_file.clicked.connect(self._load_from_file)
        self.btn_generate.clicked.connect(self._generate)

    def _on_template_changed(self, current: QListWidgetItem, _previous):
        if current is None:
            return
        key = current.data(Qt.UserRole)
        tpl = TEMPLATES[key]
        self.editor.setPlainText(tpl.tree)
        self.statusBar().showMessage(f"Template carregado: {tpl.name}")

    def _refresh_preview(self) -> None:
        items = parse_tree(self.editor.toPlainText())
        if not items:
            self.preview.setPlainText("(árvore vazia ou inválida)")
            return
        self.preview.setPlainText(tree_preview(items))

    def _choose_dest(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Escolher pasta de destino")
        if folder:
            self.dest_input.setText(folder)

    def _load_from_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Selecionar arquivo de template", "", "Texto (*.txt);;Todos (*.*)"
        )
        if not path:
            return
        try:
            content = Path(path).read_text(encoding="utf-8")
            self.editor.setPlainText(content)
            self.statusBar().showMessage(f"Arquivo carregado: {path}")
        except Exception as exc:
            QMessageBox.critical(self, "Erro", f"Falha ao ler arquivo:\n{exc}")

    def _current_template_files(self) -> dict:
        item = self.template_list.currentItem()
        if not item or not self.chk_use_files.isChecked():
            return {}
        key = item.data(Qt.UserRole)
        return TEMPLATES[key].files

    def _generate(self) -> None:
        items = parse_tree(self.editor.toPlainText())
        if not items:
            QMessageBox.warning(self, "Atenção", "Árvore vazia ou inválida.")
            return

        dest_str = self.dest_input.text().strip()
        if not dest_str:
            QMessageBox.warning(self, "Atenção", "Escolha uma pasta de destino.")
            return

        dest = Path(dest_str)

        if self.chk_dry.isChecked():
            preview = tree_preview(items)
            QMessageBox.information(
                self,
                "Dry-run",
                f"Seriam criados em:\n{dest.resolve()}\n\n{preview}",
            )
            return

        try:
            logs: list[str] = []
            create_structure(
                items,
                dest,
                file_contents=self._current_template_files(),
                log=logs.append,
            )
            self.statusBar().showMessage(
                f"OK — {len(logs)} itens criados em {dest.resolve()}"
            )
            QMessageBox.information(
                self,
                "Concluído",
                f"Estrutura criada em:\n{dest.resolve()}\n\nItens: {len(logs)}",
            )
            if self.chk_open.isChecked():
                open_in_explorer(dest)
        except Exception as exc:
            QMessageBox.critical(self, "Erro ao criar estrutura", str(exc))


def run() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("Project Tree Generator")
    font = QFont("Segoe UI", 10)
    app.setFont(font)
    win = GeneratorWindow()
    win.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(run())
