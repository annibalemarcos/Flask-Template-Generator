"""Entry point — abre a interface gráfica."""
from gui import run

if __name__ == "__main__":
    raise SystemExit(run())
