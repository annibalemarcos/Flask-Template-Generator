"""
generator.py — Núcleo de parsing e criação de estruturas a partir de árvore ASCII.

Funciona tanto via importação (GUI) quanto via CLI:
    python generator.py -input template.txt -output ./meu_projeto
"""

from __future__ import annotations

import argparse
import os
import platform
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, List, Optional, Tuple


# -------------------- Parsing --------------------

@dataclass(frozen=True)
class TreeItem:
    level: int          # nível de indentação (0 = raiz)
    name: str           # nome do arquivo/diretório (sem barras)
    is_file: bool       # True se for arquivo


_BRANCH_RE = re.compile(r"[├└]")
_CLEAN_RE = re.compile(r"[│├└─]+")
_LEVEL_WIDTH = 4  # cada nível ocupa 4 colunas no padrão "│   " / "├── "


def parse_tree(content: str) -> List[TreeItem]:
    """
    Converte texto em árvore ASCII para uma lista de TreeItem.

    Estratégia:
      - A raiz (sem ├/└) recebe nível 0.
      - Para demais linhas, o nível é determinado pela COLUNA do indicador
        '├' ou '└', dividida por 4 (largura padrão de cada nível), +1.
        Isso é robusto para ramos finais onde não há '│' na coluna acima.
      - Linhas em branco e comentários após '#' são ignorados.
      - Itens terminados em '/' são diretórios; com ponto no nome (sem '/') são arquivos.
    """
    items: List[TreeItem] = []

    for raw_line in content.splitlines():
        line = raw_line.split("#", 1)[0].rstrip()
        if not line.strip():
            continue

        match = _BRANCH_RE.search(line)
        if match is None:
            # raiz / linha sem indicador de ramo
            level = 0
        else:
            level = match.start() // _LEVEL_WIDTH + 1

        cleaned = _CLEAN_RE.sub(" ", line).strip()
        if not cleaned:
            continue

        name = cleaned.strip()
        is_dir_marker = name.endswith("/")
        name = name.rstrip("/").strip()

        if not name:
            continue

        is_file = ("." in name) and not is_dir_marker
        items.append(TreeItem(level=level, name=name, is_file=is_file))

    return items


# -------------------- Criação --------------------

def create_structure(
    items: List[TreeItem],
    base_path: Path,
    file_contents: Optional[dict] = None,
    log: Optional[Callable[[str], None]] = None,
) -> List[Path]:
    """
    Cria diretórios e arquivos a partir da lista de TreeItem.

    Args:
        items: lista parseada
        base_path: diretório onde a estrutura será criada
        file_contents: dict opcional {nome_do_arquivo: conteúdo_string} para popular arquivos
        log: callback para mensagens (GUI ou CLI)

    Returns:
        Lista de caminhos criados.
    """
    file_contents = file_contents or {}
    logger = log or (lambda msg: print(msg))

    base_path = Path(base_path)
    base_path.mkdir(parents=True, exist_ok=True)

    created: List[Path] = []
    level_paths: dict = {-1: base_path}

    for item in items:
        parent_level = item.level - 1
        while parent_level not in level_paths and parent_level >= -1:
            parent_level -= 1
        parent_path = level_paths[parent_level]
        current_path = parent_path / item.name

        if item.is_file:
            current_path.parent.mkdir(parents=True, exist_ok=True)
            content = file_contents.get(item.name, "")
            current_path.write_text(content, encoding="utf-8")
            logger(f"  arquivo  -> {current_path}")
        else:
            current_path.mkdir(parents=True, exist_ok=True)
            level_paths[item.level] = current_path
            # remove níveis filhos antigos
            for k in [k for k in level_paths if k > item.level]:
                del level_paths[k]
            logger(f"  pasta    -> {current_path}")

        created.append(current_path)

    return created


# -------------------- Util --------------------

def open_in_explorer(path: Path) -> None:
    """Abre o diretório no explorador de arquivos do SO."""
    path = Path(path)
    try:
        system = platform.system()
        if system == "Windows":
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif system == "Darwin":
            subprocess.run(["open", str(path)], check=True)
        else:
            subprocess.run(["xdg-open", str(path)], check=True)
    except Exception as exc:
        print(f"Não foi possível abrir o diretório automaticamente: {exc}")


def tree_preview(items: Iterable[TreeItem]) -> str:
    """Gera string formatada de preview indentado (para a GUI)."""
    lines = []
    for it in items:
        indent = "    " * max(it.level - 1, 0)
        marker = "📄" if it.is_file else "📁"
        lines.append(f"{indent}{marker} {it.name}")
    return "\n".join(lines)


# -------------------- CLI --------------------

def _cli(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Gera estrutura de diretórios/arquivos a partir de template ASCII.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("-input", required=True, help="Arquivo template (.txt) com árvore ASCII")
    parser.add_argument("-output", required=True, help="Pasta de destino")
    parser.add_argument("--open", action="store_true", help="Abrir pasta ao terminar")
    args = parser.parse_args(argv)

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Arquivo não encontrado: {input_path}")
        return 1

    content = input_path.read_text(encoding="utf-8")
    items = parse_tree(content)
    if not items:
        print("Nenhuma estrutura válida encontrada no template.")
        return 1

    out = Path(args.output)
    print(f"Criando estrutura em: {out.resolve()}")
    create_structure(items, out)
    print("Concluído.")

    if args.open:
        open_in_explorer(out)
    return 0


if __name__ == "__main__":
    sys.exit(_cli())
