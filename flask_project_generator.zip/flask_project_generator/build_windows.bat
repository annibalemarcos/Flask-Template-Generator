@echo off
REM ============================================================
REM build_windows.bat — Empacota o Project Tree Generator (Windows)
REM
REM Requisitos:
REM   - Python 3.10+ no PATH
REM   - (Opcional) Inno Setup 6 instalado em
REM     "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
REM     para gerar o instalador .exe automaticamente.
REM ============================================================

setlocal enableextensions enabledelayedexpansion
cd /d "%~dp0"

echo.
echo === [1/5] Criando venv ===========================================
if not exist ".venv\Scripts\python.exe" (
    python -m venv .venv || goto :err
)
call .venv\Scripts\activate.bat || goto :err

echo.
echo === [2/5] Instalando dependencias ================================
python -m pip install --upgrade pip wheel setuptools || goto :err
python -m pip install -r requirements.txt           || goto :err
python -m pip install pyinstaller==6.10.0           || goto :err

echo.
echo === [3/5] Limpando builds anteriores =============================
if exist build  rmdir /s /q build
if exist dist   rmdir /s /q dist
if exist installer\Output rmdir /s /q installer\Output

echo.
echo === [4/5] Empacotando com PyInstaller ============================
pyinstaller --noconfirm ProjectTreeGenerator.spec || goto :err

if not exist "dist\ProjectTreeGenerator\ProjectTreeGenerator.exe" (
    echo [ERRO] PyInstaller nao gerou o executavel esperado.
    goto :err
)
echo  -> dist\ProjectTreeGenerator\ProjectTreeGenerator.exe pronto.

echo.
echo === [5/5] Gerando instalador (Inno Setup) ========================
set "ISCC=C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
    echo  -> Inno Setup nao encontrado em "%ISCC%".
    echo  -> Instale em https://jrsoftware.org/isinfo.php e rode novamente,
    echo     ou rode manualmente:  "%ISCC%" installer\installer.iss
    goto :done_no_installer
)

"%ISCC%" installer\installer.iss || goto :err
echo.
echo Instalador criado em: installer\Output\
dir /b installer\Output

:done_no_installer
echo.
echo ============================================================
echo BUILD CONCLUIDO COM SUCESSO
echo  - Executavel : dist\ProjectTreeGenerator\ProjectTreeGenerator.exe
echo  - Instalador : installer\Output\ (se Inno Setup estava instalado)
echo ============================================================
exit /b 0

:err
echo.
echo ============================================================
echo FALHA NO BUILD. Verifique mensagens acima.
echo ============================================================
exit /b 1
