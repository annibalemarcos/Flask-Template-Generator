"""
templates_data.py — Biblioteca de templates prontos.

Cada template contém:
  - name: nome de exibição
  - description: descrição curta
  - tree: estrutura em árvore ASCII (string)
  - files: dict opcional {nome_do_arquivo: conteúdo_inicial}
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict


@dataclass
class ProjectTemplate:
    key: str
    name: str
    description: str
    tree: str
    files: Dict[str, str] = field(default_factory=dict)


# -------------------- Flask --------------------

FLASK_APP_PY = '''\
from flask import Flask, render_template

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
'''

FLASK_INDEX_HTML = '''\
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Meu App Flask</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='css/style.css') }}">
</head>
<body>
    <h1>Olá, Flask!</h1>
    <script src="{{ url_for('static', filename='js/app.js') }}"></script>
</body>
</html>
'''

FLASK_CSS = "body { font-family: sans-serif; margin: 2rem; }\n"
FLASK_JS = "console.log('App carregado.');\n"
FLASK_REQS = "Flask>=3.0\n"
FLASK_README = "# Meu App Flask\n\nRode com: `python app.py`\n"
FLASK_RUN_BAT = "@echo off\npython app.py\npause\n"
FLASK_OPEN_BAT = "@echo off\nstart http://localhost:5000\n"

FLASK_TEMPLATE = ProjectTemplate(
    key="flask",
    name="Flask (Web App)",
    description="App Flask com templates, static (css/js), run.bat e requirements.txt",
    tree="""\
novo_projeto_flask/
├── static/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── app.js
├── templates/
│   └── index.html
├── app.py
├── open_cmd.bat
├── README.md
├── requirements.txt
└── run.bat
""",
    files={
        "app.py": FLASK_APP_PY,
        "index.html": FLASK_INDEX_HTML,
        "style.css": FLASK_CSS,
        "app.js": FLASK_JS,
        "requirements.txt": FLASK_REQS,
        "README.md": FLASK_README,
        "run.bat": FLASK_RUN_BAT,
        "open_cmd.bat": FLASK_OPEN_BAT,
    },
)


# -------------------- FastAPI --------------------

FASTAPI_MAIN = '''\
from fastapi import FastAPI

app = FastAPI(title="Meu App FastAPI")


@app.get("/")
def root():
    return {"message": "Olá, FastAPI!"}
'''

FASTAPI_REQS = "fastapi>=0.110\nuvicorn[standard]>=0.27\n"
FASTAPI_README = "# Meu App FastAPI\n\nRode com: `uvicorn app.main:app --reload`\n"
FASTAPI_INIT = ""

FASTAPI_TEMPLATE = ProjectTemplate(
    key="fastapi",
    name="FastAPI (API REST)",
    description="API moderna em FastAPI com Uvicorn",
    tree="""\
novo_projeto_fastapi/
├── app/
│   ├── __init__.py
│   ├── main.py
│   └── routers/
│       └── __init__.py
├── tests/
│   └── __init__.py
├── requirements.txt
└── README.md
""",
    files={
        "main.py": FASTAPI_MAIN,
        "__init__.py": FASTAPI_INIT,
        "requirements.txt": FASTAPI_REQS,
        "README.md": FASTAPI_README,
    },
)


# -------------------- Django --------------------

DJANGO_MANAGE = '''\
#!/usr/bin/env python
"""Django manage.py."""
import os
import sys


def main():
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
    from django.core.management import execute_from_command_line
    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    main()
'''

DJANGO_REQS = "Django>=5.0\n"
DJANGO_README = "# Meu App Django\n\nRode com: `python manage.py runserver`\n"

DJANGO_TEMPLATE = ProjectTemplate(
    key="django",
    name="Django (Full Web)",
    description="Projeto Django com app inicial e estrutura config/",
    tree="""\
novo_projeto_django/
├── config/
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── app/
│   ├── __init__.py
│   ├── admin.py
│   ├── apps.py
│   ├── models.py
│   ├── views.py
│   └── urls.py
├── manage.py
├── requirements.txt
└── README.md
""",
    files={
        "manage.py": DJANGO_MANAGE,
        "requirements.txt": DJANGO_REQS,
        "README.md": DJANGO_README,
    },
)


# -------------------- React (Vite) --------------------

REACT_PKG = '''\
{
  "name": "novo-projeto-react",
  "private": true,
  "version": "0.0.1",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.3.0",
    "vite": "^5.4.0"
  }
}
'''

REACT_APP_JSX = '''\
export default function App() {
  return <h1>Olá, React!</h1>;
}
'''

REACT_MAIN_JSX = '''\
import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";

createRoot(document.getElementById("root")).render(<App />);
'''

REACT_INDEX_HTML = '''\
<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <title>Novo Projeto React</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
'''

REACT_TEMPLATE = ProjectTemplate(
    key="react",
    name="React + Vite",
    description="SPA React moderna com Vite",
    tree="""\
novo_projeto_react/
├── src/
│   ├── App.jsx
│   └── main.jsx
├── index.html
├── package.json
└── README.md
""",
    files={
        "package.json": REACT_PKG,
        "App.jsx": REACT_APP_JSX,
        "main.jsx": REACT_MAIN_JSX,
        "index.html": REACT_INDEX_HTML,
        "README.md": "# Novo Projeto React\n\n`npm install && npm run dev`\n",
    },
)


# -------------------- Node / Express --------------------

NODE_INDEX = '''\
const express = require("express");
const app = express();
const PORT = process.env.PORT || 3000;

app.get("/", (_req, res) => res.send("Olá, Express!"));

app.listen(PORT, () => console.log(`Servidor em http://localhost:${PORT}`));
'''

NODE_PKG = '''\
{
  "name": "novo-projeto-node",
  "version": "1.0.0",
  "main": "src/index.js",
  "scripts": { "start": "node src/index.js" },
  "dependencies": { "express": "^4.19.2" }
}
'''

NODE_TEMPLATE = ProjectTemplate(
    key="node",
    name="Node.js + Express",
    description="API simples em Node/Express",
    tree="""\
novo_projeto_node/
├── src/
│   └── index.js
├── package.json
└── README.md
""",
    files={
        "index.js": NODE_INDEX,
        "package.json": NODE_PKG,
        "README.md": "# Node + Express\n\n`npm install && npm start`\n",
    },
)


# -------------------- Python CLI --------------------

PYCLI_MAIN = '''\
"""CLI principal."""
import argparse


def main():
    parser = argparse.ArgumentParser(description="Meu CLI")
    parser.add_argument("--nome", default="mundo")
    args = parser.parse_args()
    print(f"Olá, {args.nome}!")


if __name__ == "__main__":
    main()
'''

PYCLI_TEMPLATE = ProjectTemplate(
    key="python_cli",
    name="Python CLI",
    description="Aplicativo de linha de comando em Python puro",
    tree="""\
novo_projeto_cli/
├── src/
│   ├── __init__.py
│   └── main.py
├── tests/
│   └── test_main.py
├── requirements.txt
└── README.md
""",
    files={
        "main.py": PYCLI_MAIN,
        "__init__.py": "",
        "test_main.py": "def test_smoke():\n    assert True\n",
        "requirements.txt": "",
        "README.md": "# Python CLI\n\n`python -m src.main --nome Ana`\n",
    },
)


# -------------------- Registro --------------------

TEMPLATES: Dict[str, ProjectTemplate] = {
    t.key: t
    for t in [
        FLASK_TEMPLATE,
        FASTAPI_TEMPLATE,
        DJANGO_TEMPLATE,
        REACT_TEMPLATE,
        NODE_TEMPLATE,
        PYCLI_TEMPLATE,
    ]
}
