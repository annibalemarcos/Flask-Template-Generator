# Project Tree Generator

Gerador gráfico de estruturas de projeto a partir de árvores ASCII.
Versão evoluída do seu `template_generator.py`, agora com:

- Interface gráfica desktop em **PySide6** (Qt for Python) com tema escuro moderno
- **Templates prontos** (Flask, FastAPI, Django, React + Vite, Node/Express, Python CLI)
- Editor de árvore com **pré-visualização em tempo real**
- Conteúdo inicial automático em arquivos conhecidos (ex.: `app.py` Flask já vem com código base)
- Carregamento de arquivos `.txt` no formato árvore ASCII
- Modo **Dry-run** (mostra o que seria criado sem mexer no disco)
- Abrir pasta gerada ao final
- CLI mantida (compatível com seu uso original)

---

## Instalação

```bash
cd flask_project_generator
python -m venv .venv
# Windows
.venv\Scripts\activate
# Linux/macOS
source .venv/bin/activate

pip install -r requirements.txt
```

## Uso (GUI)

```bash
python main.py
```

1. Selecione um template à esquerda (ou edite/cole sua própria árvore).
2. Veja a pré-visualização no painel direito.
3. Escolha a pasta de destino.
4. (Opcional) Ative **Dry-run** para apenas pré-visualizar.
5. Clique em **Gerar estrutura**.

## Uso (CLI — compatível com o script original)

```bash
python generator.py -input template.txt -output ./meu_projeto
python generator.py -input template.txt -output ./meu_projeto --open
```

## Formato do template

```
meu_projeto/
├── static/
│   ├── css/
│   └── js/
├── templates/
│   └── index.html
├── app.py
├── requirements.txt
└── README.md
```

Regras:
- Linhas terminadas em `/` são **diretórios**.
- Nomes contendo ponto (ex.: `app.py`) são **arquivos**.
- Caracteres de árvore aceitos: `├`, `└`, `│`, `─`.
- Comentários após `#` são ignorados.

## Empacotar como executável (opcional)

```bash
pip install pyinstaller
pyinstaller --noconfirm --onefile --windowed --name "ProjectTreeGenerator" main.py
```

O binário ficará em `dist/`.
