# Build & Empacotamento — Project Tree Generator (Windows)

Este guia explica como gerar o **executável** e o **instalador `.exe`** do
Project Tree Generator para Windows.

Você tem **três opções**:

| Opção | Onde rodar | Saída |
|---|---|---|
| **A. Build local no Windows** | Sua máquina Windows | `.exe` portátil + instalador `.exe` |
| **B. GitHub Actions (recomendado)** | Online, grátis | Instalador `.exe` baixável como artefato/release |
| **C. Apenas o portátil (sem instalador)** | Windows, sem Inno Setup | Pasta `dist/` com o `.exe` |

---

## Estrutura entregue

```
flask_project_generator/
├── .github/workflows/build-windows.yml   # build automático (opção B)
├── assets/
│   ├── icon.ico                          # ícone do app/instalador
│   └── icon.png
├── installer/
│   └── installer.iss                     # script Inno Setup
├── ProjectTreeGenerator.spec             # config do PyInstaller
├── build_windows.bat                     # build local 1-clique (opção A)
├── main.py, gui.py, generator.py, templates_data.py
├── requirements.txt
└── README.md / README_BUILD.md
```

---

## Opção A — Build local no Windows (recomendado para teste rápido)

### Pré-requisitos
1. **Python 3.10+** (64 bits) — marque "Add Python to PATH" durante a instalação.
   <https://www.python.org/downloads/windows/>
2. **Inno Setup 6** (apenas se quiser o instalador `.exe`) —
   <https://jrsoftware.org/isinfo.php>

### Passos
1. Descompacte o ZIP entregue.
2. Dê duplo-clique em **`build_windows.bat`**.
3. Aguarde. Ao final você terá:
   - **Executável portátil:** `dist\ProjectTreeGenerator\ProjectTreeGenerator.exe`
   - **Instalador:** `installer\Output\ProjectTreeGenerator-Setup-1.0.0.exe`
     *(somente se o Inno Setup estiver instalado)*

> O `build_windows.bat` cria um `.venv` local, instala as dependências,
> roda o `PyInstaller` com o `.spec` e chama o `ISCC.exe` (Inno Setup).

---

## Opção B — GitHub Actions (build automático na nuvem)

Sem precisar de máquina Windows. O workflow `.github/workflows/build-windows.yml`
roda em `windows-latest`, gera o `.exe` e o instalador, e os disponibiliza
como **artefatos** (e como **release** se você criar uma tag `vX.Y.Z`).

### Passos
1. Crie um repositório no GitHub e envie estes arquivos.
2. Vá na aba **Actions → Build Windows Installer → Run workflow**
   (ou faça push para `main`).
3. Após ~3-5 min, baixe na própria página da execução:
   - `ProjectTreeGenerator-portable` (pasta zipada)
   - `ProjectTreeGenerator-installer` (`.exe` do instalador)
4. Para release pública automática, crie uma tag:
   ```bash
   git tag v1.0.0
   git push --tags
   ```
   O instalador é anexado em **Releases** automaticamente.

---

## Opção C — Apenas o executável portátil

No Windows, com Python instalado:

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
pip install pyinstaller==6.10.0
pyinstaller --noconfirm ProjectTreeGenerator.spec
```

Saída: `dist\ProjectTreeGenerator\ProjectTreeGenerator.exe`
(pode ser copiado e executado em qualquer Windows 10/11 x64).

---

## Personalização rápida

| O que mudar | Onde |
|---|---|
| Versão do app | `installer/installer.iss` → `MyAppVersion` |
| Nome / publisher | `installer/installer.iss` → `MyAppName`, `MyAppPublisher` |
| Ícone | substitua `assets/icon.ico` |
| Atalho na área de trabalho por padrão | `installer.iss` → remova `Flags: unchecked` da task `desktopicon` |
| Instalação para *todos os usuários* | `installer.iss` → `PrivilegesRequired=admin` e `DefaultDirName={pf}\ProjectTreeGenerator` |

---

## Troubleshooting

- **"python não é reconhecido"** → reinstale o Python marcando *Add to PATH*.
- **PyInstaller acusa `PySide6` ausente** → confirme `.venv` ativo e
  `pip install -r requirements.txt`.
- **Antivírus bloqueia o `.exe`** → comum com binários PyInstaller não
  assinados. Para distribuição comercial, considere assinar com um
  certificado *code-signing*.
- **Instalador não abre o app** → verifique se o `.exe` está em
  `dist\ProjectTreeGenerator\` antes de compilar o `.iss`.

---

## Resumo dos comandos

```bat
:: build local 1-clique
build_windows.bat

:: build manual
pyinstaller --noconfirm ProjectTreeGenerator.spec
"C:\Program Files (x86)\Inno Setup 6\ISCC.exe" installer\installer.iss
```
